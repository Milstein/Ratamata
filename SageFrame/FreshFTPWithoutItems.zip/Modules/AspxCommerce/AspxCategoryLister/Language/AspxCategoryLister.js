﻿
var AspxCategoryLister = {

   
       "This store has no category found!": "This store has no category found!",
    "Categories": "Categories",

   
       'home': 'home',
    'Shopping Options': 'Shopping Options',

    'Tags': 'Tags',
    'Search': 'Search'
};