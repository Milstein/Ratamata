﻿var AspxReferToFriendManagement={
"Delete Confirmation":"Delete Confirmation",
"Do you want to delete all selected items?":"Do you want to delete all selected items?",
"Information Alert":"Information Alert",
"You need to select at least one item before you can do this":"You need to select at least one item before you can do this",
"EmailAFriendID":"EmailAFriendID",
"Item ID":"Item ID",
"Sender Name":"Sender Name",
"Sender Email":"Sender Email",
"Receiver Name":"Receiver Name",
"Receiver Email":"Receiver Email",
"Subject":"Subject",
"Message":"Message",
"Store ID":"Store ID",
"Portal ID":"Portal ID",
"Active":"Active",
"Is Deleted":"Is Deleted",
"Is Modified":"Is Modified",
"Send On":"Send On",
"Updated On":"Updated On",
"Deleted On":"Deleted On",
"Added By":"Added By",
"Updated By":"Updated By",
"Deleted By":"Deleted By",
"Actions":"Actions",
"Delete":"Delete",
"No Records Found!":"No Records Found!"









};