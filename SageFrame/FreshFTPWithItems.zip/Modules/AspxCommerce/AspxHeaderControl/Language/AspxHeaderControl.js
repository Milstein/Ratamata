﻿

var AspxHeaderControl = {
//HeaderControl.ascx
    "Account": "Account",
    "My Account": "My Account",
    "My Categories": "My Categories",
    "My Added Items": "My Added Items",
    "Checkout": "Checkout",
    "Close": "Close",

       "Welcome": "Welcome",
    "Guest": "Guest",
    "Information Alert": "Information Alert",
    "You can't proceed to checkout your amount is not applicable!": "You can't proceed to checkout your amount is not applicable!",
    "You have not added any items in cart yet!": "You have not added any items in cart yet!",
    "You are not eligible to proceed further. Your order amount must be at least": "You are not eligible to proceed further because of low order amount. Your order amount must be at least ",
    'Checkout With Single Address': 'Checkout With Single Address',
    'Checkout With Multiple Addresses': 'Checkout With Multiple Addresses',
    'Checkout is not allowed for anonymous user!': 'Checkout is not allowed for anonymous user!',
    'OR': 'OR',
    "My Wishlist": "My Wishlist",
    "My Cart": "My Cart",
    "Notice Information": "Notice Information",
    "Your cart contains items. Do you want to look at them?": "Your cart contains items. Do you want to look at them?",
    "Save": "Save",
    "Setting Saved Successfully": "Setting Saved Successfully",
       "Header Settings": "Header Settings",
    "Horizontal": "Horizontal",
    "Dropdown": "Dropdown",
    "Save": "Save"
};