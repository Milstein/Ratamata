﻿var PersonalizationLanguage = {

    'Information Alert': 'Information Alert',
    'Setting Saved Successfully': 'Setting Saved Successfully'
};

var AspxLatestItem = {

    //LatestItems.ascx
    "View Full Product Detail": "View Full Product Detail",
    //LatestItems.js
    "Regular Price :": "Regular Price :",
    "Our Offer :": "Our Offer :",
    "Details": "Details",
    "Wishlist": "Wishlist",
    "Compare": "Compare",
    "More than": "More than",

    "Add to cart": "Add to cart",
    "This store has no items listed yet!": "This store has no items listed yet!",
    'items are not allowed to add in compare list!': 'items are not allowed to add in compare list!',
    'The selected item already exist in compare list.': 'The selected item already exist in compare list.',
    'Item has been successfully added to compare list.': 'Item has been successfully added to compare list.',
    'The selected item already exist in your wishlist.': 'The selected item already exist in your wishlist.',

    "(Bulk Discount available)": "(Bulk Discount available)",
    "Item quantity discounts:": "Item quantity discounts:",
    "Quantity (more than)": "Quantity (more than)",
    "Add to Cart": "Add to Cart",
    "Continue Shopping": "Continue Shopping",
    "Close": "Close",


    //LatestItemsCarousel.ascx

    //LatestItemsCarousel.js
    //For Quick View
    'Quick Look': 'Quick Look',
    'Available': 'Available',
    'Not Available': 'Not Available',
    'In stock': 'In stock',
    'Out Of Stock': 'Out Of Stock',
    "This product is out of stock!": "This product is out of stock!",
    "Not required": "Not required",
    "Don't use this option": "Don't use this option",
    "Successful Message": "Successful Message",
    'Item has been successfully added to cart.': 'Item has been successfully added to cart.',
    'Failed to load cost variants!': 'Failed to load cost variants!',
    'Failed to save!': 'Failed to save!',
    'Failed to add item to cart!': 'Failed to add item to cart!',
    'Price :': 'Price :',
    "Price": "Price",
    'Invalid quantity.': 'Invalid quantity.',
    'Information Alert': 'Information Alert',
    'This product is currently out of stock!': 'This product is currently out of stock!',
    'Please choose available variants!': 'Please choose available variants!',
    'The quantity is greater than the available quantity.': 'The quantity is greater than the available quantity.',
    'Information Message': 'Information Message',
    "Item Quantity Discount:": "Item Quantity Discount:",
    "Price Per Unit": "Price Per Unit",
    "Error Message": "Error Message",
    "Brand": "Brand",
    "View all items under this brand": "View all items under this brand",
    "Note:- select your card theme": "Note:- select your card theme",
    "Please fill valid required data!": "Please fill valid required data!",
    "Price History": "Price History",
    "Date": "Date",
    "View": "View"
};

var AspxRecentlyViewedItems = {
    //RecentlyViewedItems.js
    "You have not viewed any items yet!": "You have not viewed any items yet!",
    "View More": "View More"
};

var AspxFrontItemGallery = {
    //FrontItemGallery.js
    'Featured products': 'Featured products',
    'This store has no featured items found!': 'This store has no featured items found!',
    'Price: ': 'Price: ',
    'This store has no special items found!': 'This store has no special items found!',
    'Special products': 'Special products',
    "Setting Saved Successfully": "Setting Saved Successfully"
};