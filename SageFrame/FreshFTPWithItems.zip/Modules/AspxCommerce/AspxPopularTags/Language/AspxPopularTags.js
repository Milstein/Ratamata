﻿

var AspxPopularTags={
    
       
       "Not any items have been tagged yet!":"Not any items have been tagged yet!",
    'View All Tags':'View All Tags',

       "AspxCommerce Popular Tags":"AspxCommerce Popular Tags",
    "AspxCommerce New Tag": "AspxCommerce New Tag",
    "Popular Tag Rss Feed Title":"Popular Tag Rss Feed Title",
    "Popular Tag Rss Feed Alt": "Popular Tag Rss Feed Alt",

    
       "Sorry, Failed to load tag items!": "Sorry, Failed to load tag items!",
    'Not any items have been tagged yet!': 'Not any items have been tagged yet!',
    'See all pages tagged with': 'See all pages tagged with',
    "Error Message": "Error Message"
};