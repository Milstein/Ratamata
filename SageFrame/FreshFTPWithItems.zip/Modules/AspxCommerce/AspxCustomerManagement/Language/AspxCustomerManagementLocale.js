﻿var AspxCustomerManagement = {
    
    "Are you sure you want to delete customer?": "Are you sure you want to delete customer?",
    "Sorry! You can not delete yourself.": "Sorry! You can not delete yourself.",
    "Customer ID": "Customer ID",
    "Culture Name": "Culture Name",
    "Added On": "Added On",
    "UpdatedOn": "UpdatedOn",
    "is Same User": "is Same User",
    "Delete": "Delete",
    "Successful Message": "Successful Message",
    "Customer has been deleted successfully.": "Customer has been deleted successfully.",
    "Selected customer(s) has been deleted successfully.": "Selected customer(s) has been deleted successfully.",
    "Failed to delete Customer!": "Failed to delete Customer!",
    "Error Message": "Error Message",
    "Customer has been created successfully.": "Customer has been created successfully.",
    "Delete Confirmation": "Delete Confirmation",
    "Are you sure you want to delete the selected customer(s)?": "Are you sure you want to delete the selected customer(s)?",
    "Information Alert": "Information Alert",
    "Please select at least one customer before delete.": "Please select at least one customer before delete.",
    "Period": "Period",
    "Number Of New Accounts": "Number Of New Accounts",
    "User Name": "User Name",
    "Session User Host Address": "Session User Host Address",
    "Session User Agent": "Session User Agent",
    "Session Browser": "Session Browser",
    "Session URL": "Session URL",
    "Start Time": "Start Time",
    "No Records Found!": "No Records Found!",
    'Customer Name': 'Customer Name',
    'Total Order Amount': 'Total Order Amount',
    'Number Of Orders': 'Number Of Orders',
    'Average Order Amount': 'Average Order Amount',
    'Actions': 'Actions',
    "Export to CSV": "Export to CSV",
    "User Name:": "User Name:",
    "Search": "Search",
    "Add New Customer": "Add New Customer",
    "Delete All Selected": "Delete All Selected",
    "Fields marked with * are compulsory.": "Fields marked with * are compulsory.",
    "User Info": "User Info",
    "Create Login": "Create Login",
    "Back": "Back",
    "Show Reports:": "Show Reports:",
    "Show Year Monthly Report": "Show Year Monthly Report",
    "Show Current Month Weekly Report": "Show Current Month Weekly Report",
    "Show Today's Report": "Show Today's Report",
    "Host Address:": "Host Address:",
    " Browser Name:": " Browser Name:",
    "Customer Name:": "Customer Name:",
    "Added On":"Added On",
    "Updated On":"Updated On",
    "View":"View",
    "Register":"Register",
    "Wishlist Item has been deleted successfully.":"Wishlist Item has been deleted successfully.",
    "Shopping Cart Item has been deleted successfully.":"Shopping Cart Item has been deleted successfully.",
    "Are you sure you want to delete the selected shopping cart items(s)?": "Are you sure you want to delete the selected shopping cart items(s)?",
    "Please select at least one shopping cart item before delete.":"Please select at least one shopping cart item before delete.",
    "The customer does not have a default Shipping address":"The customer does not have a default Shipping address"
};
    
    
    
    
    
  
    
    
    
    
    
