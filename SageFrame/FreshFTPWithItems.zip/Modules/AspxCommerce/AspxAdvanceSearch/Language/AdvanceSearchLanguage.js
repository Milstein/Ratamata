﻿
var AdvanceSearchLang = {


   
    "From:": "From:",
    "To:": "To:",
    "Search": "Search",
    "View as:": "View as:",
    "Sort by:": "Sort by:",
    "View Per Page": "View Per Page",
    "General Categories": "General Categories",
    "Gift Card Categories": "Gift Card Categories",

   
    "Valid Digits And Decimal Only": "Valid Digits And Decimal Only",
    'Information Alert': 'Information Alert',
    'To Price must be greater than From Price': 'To Price must be greater than From Price',
    'The selected item already in your wishlist.': 'The selected item already in your wishlist.',
    'Please select at least one attribute to search.': 'Please select at least one attribute to search.',
    'All Brands': 'All Brands',



       "Advanced Search": "Advanced Search",
    "Go": "Go",

       "Select Category": "Select Category",
    "--All Category--": "--All Category--",
    "What are you shopping today?": "What are you shopping today?",
    "Popular:": "Popular: ",
    "Setting Saved Successfully": "Setting Saved Successfully",
    
       "Advance Search Module Setting":"Advance Search Module Setting",   
    "Enable Advance Search:":"Enable Advance Search:",
    "Enable Brand Search:": "Enable Brand Search:",
    "No Of Items in a Row:":"No Of Items in a Row:",
    "Advance Search Page Name:": "Advance Search Page Name:",
    "Save": "Save"

};