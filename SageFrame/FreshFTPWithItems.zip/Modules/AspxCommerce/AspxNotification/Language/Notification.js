﻿var AspxNotification = {
    "A new Customer has been registered on your shop": "A new Customer has been registered on your shop",
    "Customer Name:": "Customer Name:",
    "See Customer Detail": "See Customer Detail"
}