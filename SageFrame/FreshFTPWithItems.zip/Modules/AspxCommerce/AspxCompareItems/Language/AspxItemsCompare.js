﻿

var AspxItemsCompare = {

       "Compare Items":"Compare Items",
    'No Items found in you Compare Item List.': 'No Items found in you Compare Item List.',
    'Error Message': 'Error Message',
    'Sorry, Compare list error occured!': 'Sorry, Compare list error occured!',
    'Sorry, error occured!': 'Sorry, error occured!',
    'Information Alert': 'Information Alert',
    'The selected item already in your wishlist.': 'The selected item already in your wishlist.',
    "Print": "Print",
    "Price :": "Price :",
    "Compare +": "Compare +",
    "Add to Cart": "Add to Cart",
	"Compare +": "Compare +",
    "Out Of Stock":"Out Of Stock",
    "Wishlist +":"Wishlist +",
    "Show Compare Items":"Show Compare Items",

       "My Compared Items []": "My Compared Items []",
    "Clear All": "Clear All",
    "Compare": "Compare",
    "Variants": "Variants",
    "Sorry, You can not add more than": "Sorry, You can not add more than",
    "items":"items",


   
    "You must have more than one item to compare!": "You must have more than one item to compare!",
    "Delete Confirmation": "Delete Confirmation",
    "Are you sure you want to delete this item?": "Are you sure you want to delete this item?",
    "Are you sure you want to clear compare list?": "Are you sure you want to clear compare list?",
    "My Compared Items": "My Compared Items",
    "No items have been compared yet!": "No items have been compared yet!",
    "The selected item already exist in compare list.":"The selected item already exist in compare list.",
    "Compare": "Compare",

       "Starting At": "Starting At "
    
    
    
    

};