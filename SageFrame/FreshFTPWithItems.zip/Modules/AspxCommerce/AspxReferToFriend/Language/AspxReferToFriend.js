﻿

var AspxReferToFriend = {

       "Email A Friend": "Email A Friend",
    'click here to view all details': 'click here to view all details',
    "Successful Message": "Successful Message",
    "Email has been sent successfully.": "Email has been sent successfully.",

    "Close": "Close",

    "Your Name:": "Your Name:",
    "Your Email:": "Your Email:",
    "Friend Name:": "Friend Name:",
    "Friend Email:": " Friend Email:",
    "Subject:": "Subject:",
    "Message:": "Message:",
    "Send": "Send",
    "(at least 2 chars)": "(at least 2 chars)"
};