﻿

var AspxKPILanguage = {

       "Information Alert": "Information Alert",
    'Successful Message': 'Successful Message',
    "Error Message": "Error Message",
    "Failed to load control!.": "Failed to load control!.",
    "Failed to load data!": "Failed to load data!",
    "Failed to save!": "Failed to save!",
    "Saved successfully!": "Saved successfully!",
    "Failed to save KPI visit and conversion!": "Failed to save KPI visit and conversion!",

       "Delete Confirmation": "Delete Confirmation",
    "Settings deleted successfully!": "Settings deleted successfully!",
    "Failed to delete settings!": "Failed to delete settings!",
    "Key Performance Indicator (KPI)":"Key Performance Indicator (KPI)",
    "Funnel Visualization":"Funnel Visualization",
    "Funnel Conversion Rate":"Funnel Conversion Rate",
    "Conversion Details:":"Conversion Details:",
    "Page Name":"Page Name",
    "Visit":"Visit",
    "Conversion":"Conversion",
    "Conversion Rate":"Conversion Rate",
    "Day":"Day",
    "Week":"Week",
    "Month":"Month",
    "Year":"Year",
    "All":"All",
    "Cart":"Cart",
    "Sales":"Sales",
    "Settings":"Settings",
    "Orders Breakdown by Accounts":"Orders Breakdown by Accounts",
    "Sales Breakdown by Accounts":"Sales Breakdown by Accounts",
    "New Accounts":"New Accounts",
    "Existing Accounts":"Existing Accounts",
    "Guests":"Guests",
    "Total":"Total",
    "Sales/Orders:":"Sales & Orders:",
    "Average Order Value":"Average Order Value",
    "Items/SKU Sold":"Items & SKU Sold",
    "Discounts":"Discounts",
    "Shipping":"Shipping",
    "Taxes":"Taxes",
    "Total Orders":"Total Orders",
    "Total Sales":"Total Sales",
    "Total Items":"Total Items",
    "Items/Order":"Items/Order",
    "Total SKU":"Total SKU",
    "Average":"Average",
    "Average %": "Average %",
    "Orders %": "Orders %",
    "Visitors :":"Visitors :",
    "Sort By :":"Sort By :",
    "country":"country",
    "all":"all",
    "All countries":"All countries",
    "New Visitors":"New Visitors",
    "Returning Visitors":"Returning Visitors",
    "Locations:":"Locations:",
    "Country":"Country",
    "City":"City",
    "Visits":"Visits",
    "Visits %":"Visits %",
    "Page name":"Page name",
    "Avg. Duration":"Avg. Duration",
    "No status yet, check back later.":"No status yet, check back later.",
    "Total Visits:":"Total Visits:",
    "KPI :":"KPI :",
    "Email Notification :":"Email Notification :",
    "End Date :":"End Date :",
    "* select a date":"* select a date",
    "IPInfoDB API key :":"IPInfoDB API key :",
    "Settings saved successfully!":"Settings saved successfully!",
    "Failed to save settings!":"Failed to save settings!",
    "Failed to get settings information!":"Failed to get settings information!",
    "Failed to get funnel cart information!":"Failed to get funnel cart information!"



















};
