﻿var AspxKitManagement = {
};