﻿var RecommendedItemLanguage = {

    'Information Alert': 'Information Alert',
    'Setting Saved Successfully': 'Setting Saved Successfully'
};