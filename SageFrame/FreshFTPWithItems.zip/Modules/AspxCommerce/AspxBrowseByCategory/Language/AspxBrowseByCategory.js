﻿var AspxBrowseByCategory = {
    "Browse by": "Browse by",
    "No category with item is found!": "No category with item is found!",
    "Setting Saved Successfully": "Setting Saved Successfully",
    "Save": "Save"
};